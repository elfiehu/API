
## WeatherPy

In this example, you'll be creating a Python script to visualize the weather of 500+ cities across the world of varying distance from the equator. To accomplish this, you'll be utilizing a [simple Python library](https://pypi.python.org/pypi/citipy), the [OpenWeatherMap API](https://openweathermap.org/api), and a little common sense to create a representative model of weather across world cities.

Your objective is to build a series of scatter plots to showcase the following relationships:

* Temperature (F) vs. Latitude
* Humidity (%) vs. Latitude
* Cloudiness (%) vs. Latitude
* Wind Speed (mph) vs. Latitude

Your final notebook must:

* Randomly select **at least** 500 unique (non-repeat) cities based on latitude and longitude.
* Perform a weather check on each of the cities using a series of successive API calls. 
* Include a print log of each city as it's being processed with the city number, city name, and requested URL.
* Save both a CSV of all data retrieved and png images for each scatter plot.

As final considerations:

* You must use the Matplotlib and Seaborn libraries.
* You must include a written description of three observable trends based on the data. 
* You must use proper labeling of your plots, including aspects like: Plot Titles (with date of analysis) and Axes Labels.
* You must include an exported markdown version of your Notebook called  `README.md` in your GitHub repository.  
* See [Example Solution](WeatherPy_Example.pdf) for a reference on expected format. 


```python
import openweathermapy.core as owm
import requests
import json
import matplotlib.pyplot as plt
import pandas as pd
from config import key
from citipy import citipy
import random
import math
import sys
import numpy
# create a range for random longitude and latitude
# long -180 to 180, but will use 18000 as integers, convert to 2 decimal later
# lag -90 to 90
# radius of 5 to avoid duplication of coordinates 
# random number generator
# randomly select 3 longitutde and latitude combinations = 3 cities or nearby cities for testing purposes. 
# will change to 500 cities later
# save results in list
radius = 500
lat_range = (-9000, 9000)
lon_range = (-18000, 18000)
qty = 5

deltas = set()
for lat in range (-radius, radius+1):
    for lon in range (-radius, radius+1):
        if lon*lon + lat*lat <= radius*radius:
            deltas.add((lat, lon))
coords = []
excluded = set()
i = 0
while i < qty:
    lat = random.randrange(*lat_range)/100
    lon = random.randrange(*lon_range)/100
    if (lat, lon) in excluded: continue
    coords. append((lat, lon))
    i += 1
    excluded.update((lat + dlat, lon + dlon) for (dlat, dlon) in deltas)
print (coords)
```

    [(-52.28, -103.78), (-3.65, -33.57), (27.73, 152.78), (71.48, 141.92), (43.97, 93.44)]
    


```python
from citipy import citipy
# Some random coordinates
cities = []
city_list=[]
for coordinate_pair in coords:
    lat, lon = coordinate_pair
    cities.append(citipy.nearest_city(lat, lon))
for city in cities:
    country_code = city.country_code
    city_name = city.city_name
    city_list.append(city_name + "," + country_code)
print(city_list)
```

    ['castro,cl', 'touros,br', 'hasaki,jp', 'deputatskiy,ru', 'hami,cn']
    


```python
import json
import requests
from pprint import pprint
#from config import key
url = "https://api.openweathermap.org/data/2.5/weather?appid=2271bfb7642e5e45175707f34592a152"
for city in city_list:
    query_url = url + "&q=" + city 
    weather_response = requests.get(query_url)
    weather_json = weather_response.json()
pprint (weather_json)
```

    {'base': 'stations',
     'clouds': {'all': 12},
     'cod': 200,
     'coord': {'lat': 42.84, 'lon': 93.51},
     'dt': 1519963852,
     'id': 1529484,
     'main': {'grnd_level': 933.5,
              'humidity': 50,
              'pressure': 933.5,
              'sea_level': 1015.64,
              'temp': 279.424,
              'temp_max': 279.424,
              'temp_min': 279.424},
     'name': 'Hami',
     'sys': {'country': 'CN',
             'message': 0.0089,
             'sunrise': 1519950035,
             'sunset': 1519990578},
     'weather': [{'description': 'few clouds',
                  'icon': '02d',
                  'id': 801,
                  'main': 'Clouds'}],
     'wind': {'deg': 116.502, 'speed': 2.28}}
    


```python
import json
import requests
#from config import key
#url = "http://api.openweathermap.org/data/2.5/weather?"
#query_url = f"{url}appid={key}&units={units}&q="
url = "http://api.openweathermap.org/data/2.5/weather?APPID=2271bfb7642e5e45175707f34592a152&q="
lat = []
temp = []
humidity = []
clouds = []
wind = []
for city in city_list:
    response = requests.get(url + city).json()    
    lat.append(response['coord']['lat'])
    temp.append(response['main']['temp'])
    humidity.append(response['main']['humidity'])
    clouds.append(response['clouds']['all'])
    wind.append(response['wind']['speed'])
print(f"The latitude information received is: {lat}")
print(f"The temperature information received is: {temp}")
print(f"The humidity information received is: {humidity}")
print(f"The cloudiness information received is: {clouds}")
print(f"The wind speed information received is: {wind}")
```

    The latitude information received is: [-42.48, -5.2, 35.73, 69.3, 42.84]
    The temperature information received is: [283.274, 296.224, 284.15, 246.699, 279.424]
    The humidity information received is: [100, 100, 32, 65, 50]
    The cloudiness information received is: [0, 92, 40, 76, 12]
    The wind speed information received is: [1.38, 2.73, 4.1, 2.98, 2.28]
    


```python
for city in city_list:
    url = url + city
    print (url)
```

    http://api.openweathermap.org/data/2.5/weather?APPID=2271bfb7642e5e45175707f34592a152&q=castro,cl
    http://api.openweathermap.org/data/2.5/weather?APPID=2271bfb7642e5e45175707f34592a152&q=castro,cltouros,br
    http://api.openweathermap.org/data/2.5/weather?APPID=2271bfb7642e5e45175707f34592a152&q=castro,cltouros,brhasaki,jp
    http://api.openweathermap.org/data/2.5/weather?APPID=2271bfb7642e5e45175707f34592a152&q=castro,cltouros,brhasaki,jpdeputatskiy,ru
    http://api.openweathermap.org/data/2.5/weather?APPID=2271bfb7642e5e45175707f34592a152&q=castro,cltouros,brhasaki,jpdeputatskiy,ruhami,cn
    


```python
url.to_csv("C:\\Users\\ushuel00\\Downloads\\UCI\\Homework\\API\\url.csv")
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    <ipython-input-6-db2032ffebc3> in <module>()
    ----> 1 url.to_csv("C:\\Users\\ushuel00\\Downloads\\UCI\\Homework\\API\\url.csv")
    

    AttributeError: 'str' object has no attribute 'to_csv'



```python
weather_dict = {
    "city": city_list,
    "lat": lat,
    "temp": temp,
    "humidity": humidity,
    "cloudiness": clouds,
    "wind speed": wind
}
weather_data = pd.DataFrame(weather_dict)
weather_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>cloudiness</th>
      <th>humidity</th>
      <th>lat</th>
      <th>temp</th>
      <th>wind speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>castro,cl</td>
      <td>0</td>
      <td>100</td>
      <td>-42.48</td>
      <td>283.274</td>
      <td>1.38</td>
    </tr>
    <tr>
      <th>1</th>
      <td>touros,br</td>
      <td>92</td>
      <td>100</td>
      <td>-5.20</td>
      <td>296.224</td>
      <td>2.73</td>
    </tr>
    <tr>
      <th>2</th>
      <td>hasaki,jp</td>
      <td>40</td>
      <td>32</td>
      <td>35.73</td>
      <td>284.150</td>
      <td>4.10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>deputatskiy,ru</td>
      <td>76</td>
      <td>65</td>
      <td>69.30</td>
      <td>246.699</td>
      <td>2.98</td>
    </tr>
    <tr>
      <th>4</th>
      <td>hami,cn</td>
      <td>12</td>
      <td>50</td>
      <td>42.84</td>
      <td>279.424</td>
      <td>2.28</td>
    </tr>
  </tbody>
</table>
</div>




```python

weather_data.to_csv("C:\\Users\\ushuel00\\Downloads\\UCI\\Homework\\API\\weather_data.csv", index=True, header=True)    
```


```python
# Build a scatter plot for each data type
plt.scatter(weather_data["lat"], weather_data["temp"], color = "green")
plt.title("Temperature vs latitude 3.1")
plt.ylabel("Temperature")
plt.xlabel("Latitude")
plt.grid(True)
plt.savefig("Temperature.png")
plt.show()
```


![png](output_9_0.png)



```python
plt.scatter(weather_data["lat"], weather_data["humidity"], color="blue")
plt.title("latitude vs humidity 3.1")
plt.ylabel("Humidity")
plt.xlabel("Latitude")
plt.grid(True)
plt.savefig("Humidity.png")
plt.show()
```


![png](output_10_0.png)



```python
plt.scatter(weather_data["lat"], weather_data["cloudiness"], color="grey")
plt.title("latitude vs cloudiness 3.1")
plt.ylabel("Cloudiness")
plt.xlabel("Latitude")
plt.grid(True)
plt.savefig("cloudiness.png")
plt.show()
```


![png](output_11_0.png)



```python
plt.scatter(weather_data["lat"], weather_data["wind speed"], color="red")
plt.title("latitude vs wind speed 3.1")
plt.ylabel("wind speed")
plt.xlabel("Latitude")
plt.grid(True)
plt.savefig("wind speed.png")
plt.show()
```


![png](output_12_0.png)

